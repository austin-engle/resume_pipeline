import boto3
import os

table_name = os.environ["TABLE_NAME"]

my_session = boto3.session.Session()
my_region = my_session.region_name
dynamodb_client = boto3.client("dynamodb", region_name=my_region)


def query_dynamo(table_name):
    response = dynamodb_client.query(
        TableName=table_name,
        KeyConditionExpression=f"Owner = :owner AND Website = :website",
        ExpressionAttributeValues={
            ":owner": {"S": "Austin Engle"},
            ":website": {"S": "resume"},
        },
    )

    value = response["Count"]

    if value != 0:
        viewcount = response["Items"][0]["viewcount"]["S"]

        return viewcount

    else:
        return None


def handler(event, context):
    print("hello world")

